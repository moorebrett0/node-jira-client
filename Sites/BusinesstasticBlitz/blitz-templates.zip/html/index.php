
<?php

//Header Includes

include 'template-parts/header/head-seo.php';
include 'template-parts/header/head-scripts.php';
include 'template-parts/header/masthead.php';


//General templating effects

include 'template-parts/includes/slider.php';
include 'template-parts/includes/header-two.php';
include 'template-parts/includes/three-buckets.php';
include 'template-parts/includes/gallery.php';
include 'template-parts/includes/from-the-blog.php';







//footer includes

include 'template-parts/footer/footer.php';

?>
