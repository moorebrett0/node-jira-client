<?php
// Blog header area
include '../template-parts/header/head-seo.php';
include '../template-parts/header/head-scripts.php';
include '../template-parts/header/masthead.php';

include '../template-parts/includes/header-two.php';
include '../template-parts/includes/blog-landing.php';

//Blog footer area
include '../template-parts/footer/footer.php';
  ?>
