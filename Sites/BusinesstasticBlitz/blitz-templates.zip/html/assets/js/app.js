$(document).ready(function(){
    var height = $('.content').height()
        $('.sidebar').height(height)​
    });
});
