<?php  //Header includes
include '../template-parts/header/head-seo.php';
include '../template-parts/header/head-scripts.php';
include '../template-parts/header/masthead.php';
include '../template-parts/includes/four-buckets.php';
include '../template-parts/includes/gallery-three.php';
include '../template-parts/includes/mailchimp.php';
//footer inlcudes
include '../template-parts/footer/footer.php';
?>
