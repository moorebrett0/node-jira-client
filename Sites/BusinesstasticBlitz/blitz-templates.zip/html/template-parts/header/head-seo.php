<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="http://gmpg.org/xfn/11">
    <meta http-equiv="Content-Type" content="application/xhtml+xml">
    <!-- FAVICON -->
    <link rel="icon" type="image/png" href="">
    <link rel="pingback" href="">
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" type="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="../assets/bootstrap-sass/javascripts/bootstrap.js"></script>
    <!-- Typekit -->
  <script src="https://use.typekit.net/kmr5luj.js"></script>
