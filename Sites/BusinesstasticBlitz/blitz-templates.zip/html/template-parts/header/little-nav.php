<div class="little-nav">
				<div class="container">
					<a class="logo visible-sm" href="">
						<img width="140" src="/assets/images/logo.png" />
					</a>
					<ul>
						<li><a href="#">Linked In</a></li> |
						<li><a href="#">503-555-5555</li>
					</ul>
					</p>
				</div>
			</div>
