<!-- This is where you will include your javascript files for the header -->
<script src="https://use.typekit.net/kmr5luj.js"></script>
<link rel="stylesheet" href="../assets/css/styles.css">
<link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
