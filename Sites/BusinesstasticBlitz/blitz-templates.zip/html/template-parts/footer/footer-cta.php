<div class="footer-header">
  <h1>Footer Call to Action area</h1>
  <a href="call to action" class="btn btn-default">BUTTON</a>
</div>
