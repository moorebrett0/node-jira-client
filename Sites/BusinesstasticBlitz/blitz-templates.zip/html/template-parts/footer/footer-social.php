<div class="footer-include">

<div class="footer-social">
    <ul>
        <li><a href="#"><i class="fa fa-phone"></i></a></li>
        <li><a href="#"><i class="fa fa-envelope"></i></a></li>
      <li><a href="http://facebook.com/"><i class="fa fa-facebook"></i></a></li>
      <li><a href="http://linkedin.com/"><i class="fa fa-linkedin"></i></a></li>
      <li><a href="http://twitter.com/"><i class="fa fa-twitter"></i></a></li>
      <li><a href="http://plus.google.com/"><i class="fa fa-google-plus"></i> </a></li>
    </ul>
    </div>
</div>
