<div class="sidebar">
<h2>Sidebar Header</h2>
<ul class="sidebar-links">
  <li><a href="#">About Us</a></li>
  <li><a href="#">About Us</a></li>
  <li><a href="#">About Us</a></li>
</ul>
</div>
