<div class="cover-image">
<div class="container">
  <div class="row">
    <div class="col-md-12 text-center">
      <h1 class="text-inverse">Optional header number 2</h1>
      <p class="text-inverse">Lorem ipsum dolor sit amet, consectetur adipisici eli.  This background image is optional as well</p>
      <br>
      <br>
      <a class="btn btn-default">Call to Action</a>
    </div>
  </div>
</div>
</div>
