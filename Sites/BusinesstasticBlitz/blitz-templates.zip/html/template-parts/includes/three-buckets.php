<div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-12">
        <h1 class="text-center">Program Information</h1>
      </div>
      <div class="col-xs-4 col-md-4">
        <div class="square-boxes">
          <div class="box-image">
            <img class="img-responsive" src="/assets/images/author-placeholder.png">
          </div>
          <h2 class="text-center">One Bucket</h2>
          <div class="box-info">
            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <a href="/our-programs/section-8-program/">View More Info</a>
          </div>
        </div>
      </div>
      <div class="col-xs-4 col-md-4">
        <div class="square-boxes">
          <div class="box-image">
            <img class="img-responsive" src="/assets/images/author-placeholder.png">
          </div>
          <h2 class="text-center">Two Buckets</h2>
          <div class="box-info">
            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <a href="/our-programs/affordable-housing-plans/">View More Info</a>
          </div>
        </div>
      </div>
      <div class="col-xs-4 col-md-4">
        <div class="square-boxes">
          <div class="box-image">
            <img class="img-responsive" src="/assets/images/author-placeholder.png">
          </div>
          <h2 class="text-center">3 buckets</h2>
          <div class="box-info">
            <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
            <a href="/our-programs/family-self-sufficiency/">View More Info</a>
          </div>
        </div>
      </div>
    </div>
  </div>
