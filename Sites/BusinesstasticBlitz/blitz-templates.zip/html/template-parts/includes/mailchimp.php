<div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center">Subscribe to our newsletter</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-md-offset-3 col-md-6">
            <form role="form">
              <div class="form-group">
                <div class="input-group">
                  <input type="text" class="form-control" placeholder="Enter your email">
                  <span class="input-group-btn">
                    <btn class="btn btn-default" type="submit">Sign up!</a>
                    </span>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
  </div>
