<div class="slider-container">
<div class="hero-slider">
	<div id="hero-slider-carousel" class="carousel slide" data-ride="carousel">
		<!-- Indicators -->
	  <ol class="carousel-indicators">
	    <li data-target="#hero-slider-carousel" data-slide-to="0"  class="active"></li>
			<li data-target="#hero-slider-carousel" data-slide-to="1"></li>
	 		<li data-target="#hero-slider-carousel" data-slide-to="2"></li>
	  </ol>
	  <!-- Wrapper for slides -->
	  <div class="carousel-inner" role="listbox">
	    <div class="item active" style="background-image: url(/assets/images/about-header.png);">
				<img src="/assets/images/about-header.png" alt="Slide 1" />
				<div class="container">
					<div class="slider-copy-wrapper">
						<div class="slider-copy copy-left">
			      <p>This is an example slider copy.   This field should be editable in the CMS</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nibh felis, luctus a neque lacinia, sagittis faucibus quam.</p> <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec gravida turpis ac fermentum maximus.</p>
							<a href="#" class="btn btn-default">Call to action!</a>
						</div>
		      </div>
				</div>
			</div>
			<div class="item" style="background-image: url(/assets/images/about-header.png);">
				<img src="/assets/images/about-header.png" alt="Slide 1" />
				<div class="container">
					<div class="slider-copy-wrapper">
						<div class="slider-copy copy-left">
			      <p>This is an example slider copy.   This field should be editable in the CMS</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nibh felis, luctus a neque lacinia, sagittis faucibus quam.</p> <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec gravida turpis ac fermentum maximus.</p>
							<a href="#" class="btn btn-default">Call to action!</a>
						</div>
		      </div>
				</div>
			</div>
			<div class="item" style="background-image: url(/assets/images/about-header.png);">
				<img src="/assets/images/about-header.png" alt="Slide 1" />
				<div class="container">
					<div class="slider-copy-wrapper">
						<div class="slider-copy copy-left">
			      <p>This is an example slider copy.   This field should be editable in the CMS</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed nibh felis, luctus a neque lacinia, sagittis faucibus quam.</p> <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Donec gravida turpis ac fermentum maximus.</p>
							<a href="#" class="btn btn-default">Call to action!</a>
						</div>
		      </div>
				</div>
			</div>
	  </div>
			<!-- Controls -->
		  <!-- <a class="left carousel-control" href="#hero-slider-carousel" role="button" data-slide="prev">
		    <img src="/assets/images/arrow-left-white.png" alt="White arrow pointing left" />
		    <span class="sr-only">Previous</span>
		  </a>
		  <a class="right carousel-control" href="#hero-slider-carousel" role="button" data-slide="next">
		    <img src="/assets/images/arrow-rt-white.png" alt="White arrow pointing right" />
		    <span class="sr-only">Next</span>
		  </a> -->
	</div>
</div> <!-- .hero-slider -->
</div>
