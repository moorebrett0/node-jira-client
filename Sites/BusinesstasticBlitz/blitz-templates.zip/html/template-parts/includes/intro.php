<div class="home-intro center white">
	<div class="container">
		<div id="content" class="site-content row">
			<div class="col-xs-12 col-md-8 col-md-offset-2">
				<h1>intro Example!</h1>
				<p>This is an optional introduction header.   other options include a hero-slider image as well as practically anything you would like!</p>
			</div>
		</div><!-- #content -->
	</div><!-- .container -->
</div><!-- .home-intro -->
