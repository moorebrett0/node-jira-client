<div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center">Gallery/Products 3 across the site.</h1>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div id="modal" class="modal fade">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Modal title</h4>
                  </div>
                  <div class="modal-body">
                    <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                  </div>
                  <div class="modal-footer">
                    <a class="btn btn-default" data-dismiss="modal">Close</a>
                  </div>
                </div>
              </div>
            </div>
            <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
            <h3>A title for one image</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
          </div>
          <div class="col-md-4">
            <div id="modal" class="modal fade">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Modal title</h4>
                  </div>
                  <div class="modal-body">
                    <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                  </div>
                  <div class="modal-footer">
                    <a class="btn btn-default" data-dismiss="modal">Close</a>
                  </div>
                </div>
              </div>
            </div>
            <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
            <h3>A title for one image</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
          </div>
          <div class="col-md-4">
            <div id="modal" class="modal fade">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Modal title</h4>
                  </div>
                  <div class="modal-body">
                    <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                  </div>
                  <div class="modal-footer">
                    <a class="btn btn-default" data-dismiss="modal">Close</a>
                  </div>
                </div>
              </div>
            </div>
            <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
            <h3>A title for one image</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
          </div>
        <div class="row">
          <div class="col-md-4">
            <div id="modal" class="modal fade">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">Modal title</h4>
                  </div>
                  <div class="modal-body">
                    <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                  </div>
                  <div class="modal-footer">
                    <a class="btn btn-default" data-dismiss="modal">Close</a>
                  </div>
                </div>
              </div>
            </div>
            <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
            <h3>A title for one image</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
          </div>
            <div class="col-md-4">
              <div id="modal" class="modal fade">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Modal title</h4>
                    </div>
                    <div class="modal-body">
                      <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                    </div>
                    <div class="modal-footer">
                      <a class="btn btn-default" data-dismiss="modal">Close</a>
                    </div>
                  </div>
                </div>
              </div>
              <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
              <h3>A title for one image</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
            </div>
            <div class="col-md-4">
              <div id="modal" class="modal fade">
                <div class="modal-dialog">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                      <h4 class="modal-title">Modal title</h4>
                    </div>
                    <div class="modal-body">
                      <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                    </div>
                    <div class="modal-footer">
                      <a class="btn btn-default" data-dismiss="modal">Close</a>
                    </div>
                  </div>
                </div>
              </div>
              <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
              <h3>A title for one image</h3>
              <p>Lorem ipsum dolor sit amet, consectetur adipisici elit.&nbsp;</p>
            </div>
          </div>
        </div>
      </div>
  </div>
