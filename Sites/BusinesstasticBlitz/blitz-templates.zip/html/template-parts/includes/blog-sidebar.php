<div class="col-md-4">
                <div class="sidebar">
            <!-- Blog Search Well -->
            <div class="well">
                <h4>Blog Search</h4>
                <div class="input-group">
                    <input type="text" class="form-control">
                    <span class="input-group-btn">
                        <button class="btn btn-default" type="button" Placeholder="Search the Blog">
                            <span class="glyphicon glyphicon-search"></span>
                    </button>
                    </span>
                </div>
                <h4>Header 3 sidebar title</h4>
                <p>This is a spot with some text for the blog</p>
                <h4>Recent Posts</h4>
                <div class="blog-sidebar-recent">
                        <p>Post Title</p>
                        <p>November 17th, 2015</p>
                </div>
                <div class="sidebar-categories">
                       <h4>Categories</h4>
                       <ol class="list-unstyled">
                         <li><a href="#">Fun stuff</a></li>
                         <li><a href="#">cool stuff</a></li>
                         <li><a href="#">rad stuff</a></li>
                         <li><a href="#">green stuff</a></li>
                 </ol>
               </div>
                <div class="sidebar-archives">
                        <h4>Archives</h4>
                        <ol class="list-unstyled">
                          <li><a href="#">March 2014</a></li>
                          <li><a href="#">February 2014</a></li>
                          <li><a href="#">January 2014</a></li>
                          <li><a href="#">December 2013</a></li>
                          <li><a href="#">November 2013</a></li>
                          <li><a href="#">October 2013</a></li>
                          <li><a href="#">September 2013</a></li>
                          <li><a href="#">August 2013</a></li>
                          <li><a href="#">July 2013</a></li>
                          <li><a href="#">June 2013</a></li>
                          <li><a href="#">May 2013</a></li>
                          <li><a href="#">April 2013</a></li>
                        </ol>
                      </div>
            </div>

                <!-- /.input-group -->
            </div>
    </div>
