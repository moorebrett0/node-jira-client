<div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <h1 class="text-center">Gallery for a Company</h1>
            <p class="text-center lead">A sub-title</p>
          </div>
        </div>
        <div class="row">
          <div id="modal" class="modal fade">
             <div class="modal-dialog">
               <div class="modal-content">
                 <div class="modal-header">
                   <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                   <h4 class="modal-title">Modal title</h4>
                 </div>
                 <div class="modal-body">
                   <img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive">
                 </div>
                 <div class="modal-footer">
                   <a class="btn btn-default" data-dismiss="modal">Close</a>
                 </div>
               </div>
             </div>
           </div>
          <div class="col-md-3">
            <a data-toggle="modal" data-target="#modal"><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
          <div class="col-md-3">
            <a><img src="http://pingendo.github.io/pingendo-bootstrap/assets/placeholder.png" class="img-responsive"></a>
          </div>
        </div>
      </div>
  </div>
