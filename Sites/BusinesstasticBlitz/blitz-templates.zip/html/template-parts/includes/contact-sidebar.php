<div class="col-md-4">
    <div class="row">
    <div class="sidebar">
            <!-- Blog Search Well -->
        <div class="well">
                <h4>John Doe</h4>
                <h4>Header 3 sidebar title</h4>

        </div>

                <!-- /.input-group -->
        </div>
    </div>
</div>
