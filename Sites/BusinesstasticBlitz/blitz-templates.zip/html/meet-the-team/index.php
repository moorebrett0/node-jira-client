<?php
//header information
include '../template-parts/header/head-seo.php';
include '../template-parts/header/head-scripts.php';
include '../template-parts/header/masthead.php';

//meet the team page

include '../template-parts/includes/meet-the-team.php';
include '../template-parts/includes/mailchimp.php';
include '../template-parts/includes/from-the-blog.php';








//footer includes

include '../template-parts/footer/footer.php';


?>
